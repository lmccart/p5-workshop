// Getting Started with p5.js
// Lauren McCarthy, Casey Reas, Ben Fry

// Example 2-1: comments

function setup() {
  createCanvas(300, 200);
}

function draw() {
  background(204);
  fill(165, 57, 57);
  // fill(144, 39, 39);
  // fill(40, 209, 10);
  ellipse(100, 100, 80, 80); // left circle
  ellipse(200, 100, 80, 80); // right circle
}