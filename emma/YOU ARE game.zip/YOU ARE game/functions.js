  function wellunwell() {
    // well-unwell
    background(0)
    fill(255, 0, 0)
    rect(0, 0, width, height / 2)
    fill(0, 255, 0)
    rect(0, height / 2, width, height / 2)

    textSize(100)
    fill(0, 255, 0)
    text("WELL", width / 4, height / 4, 100, 100)

    textSize(100)
    fill(255, 0, 0)
    text("UNWELL", width / 4, height * 0.6, 100, 100)

  }

  function lvlup1() {

    background(0)
    fill(255)
    textSize(250)
    text("LVLUP", 0, height / 4, 1000, 500)
    
    
   
    stroke(77, 77, 77)
    strokeWeight(10)
    fill(255,0,0)
    rect(10,height/4,175,400)
  }




  function lvlup2() {

    background(0)
    fill(255)
    textSize(250)
    text("LVLUP", 0, height / 4, 1000, 500)
    stroke(77, 77, 77)
    strokeWeight(10)
    fill(255,0,0)
    rect(10,height/4,175,400)
    rect(420,height/4, 175,400)
    
  }

  function lvlup3() {

    background(0)
    fill(255)
    textSize(250)
    text("LVLUP", 0, height / 4, 1000, 500)
  }

  function lvlup4() {

    background(0)
    fill(255)
    textSize(250)
    text("LVLUP", 0, height / 4, 1000, 500)
  }

function lvlup5() {

    background(0)
    fill(255)
    textSize(250)
    text("LVLUP", 0, height / 4, 1000, 500)
  }

function lvlup6() {

    background(0)
    fill(255)
    textSize(250)
    text("LVLUP", 0, height / 4, 1000, 500)
  }
  
  
  
  function restedunrested() {
    background(0)
    fill(0, 0, 255)
    rect(0, 0, width, height / 2)
    fill(100, 200, 0)
    rect(0, height / 2, width, height / 2)

    textSize(100)
    fill(100, 200, 0)
    text("RESTED", width / 4, height / 4, 100, 100)

    textSize(100)
    fill(0, 0, 255)
    text("UNRESTED", width / 4, height * 0.6, 100, 100)

  }


  function tireduntired() {
    background(0)
    fill(0, 0, 255)
    rect(0, 0, width, height / 2)
    fill(100, 200, 0)
    rect(0, height / 2, width, height / 2)

    textSize(100)
    fill(100, 200, 0)
    text("TIRED", width / 4, height / 4, 100, 100)

    textSize(100)
    fill(0, 0, 255)
    text("UNTIRED", width / 4, height * 0.6, 100, 100)

  }


  function relaxedunrelaxed() {
    background(0)
    fill(0, 0, 255)
    rect(0, 0, width, height / 2)
    fill(100, 200, 0)
    rect(0, height / 2, width, height / 2)

    textSize(100)
    fill(100, 200, 0)
    text("RELAXED", width / 4, height / 4, 100, 100)

    textSize(100)
    fill(0, 0, 255)
    text("UNRELAXED", width / 4, height * 0.6, 100, 100)

  }
  
  
  function confidentunconfident() {
    background(0)
    fill(0, 0, 255)
    rect(0, 0, width, height / 2)
    fill(100, 200, 0)
    rect(0, height / 2, width, height / 2)

    textSize(100)
    fill(100, 200, 0)
    text("CONFIDENT", width / 4, height / 4, 100, 100)

    textSize(100)
    fill(0, 0, 255)
    text("UNCONFIDENT", width / 4, height * 0.6, 100, 100)

  }
  
  function lovedunloved() {
    background(0)
    fill(0, 0, 255)
    rect(0, 0, width, height / 2)
    fill(100, 200, 0)
    rect(0, height / 2, width, height / 2)

    textSize(100)
    fill(100, 200, 0)
    text("LOVED", width / 4, height / 4, 100, 100)

    textSize(100)
    fill(0, 0, 255)
    text("UNLOVED", width / 4, height * 0.6, 100, 100)
  }
  