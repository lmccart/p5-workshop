var myImage;

function preload() {
  myImage = loadImage("portrait2.jpg");
}

function setup() {
  createCanvas(236, 354)
  background(myImage);
  noLoop()
}

function draw() {

  for (var x = 0; x < width; x = x + 1) {

    for (var y = 0; y < height; y = y + 1) {



      c = myImage.get(x, y);

      if (red(c) < 100 && green(c) < 100) {
        stroke(255, 0, 0)
      } else if (red(c) > 100 && green(c) > 100) {
        stroke(0, 255, 0)
      } else if (red(c) > 100 && green(c) < 100) {
        stroke(30, 30, 30)
      } else if (red(c) < 100 && green(c) > 100) {
        stroke(100, 50, 50)
      } else {
        stroke(0, 0, 255)
      }
      point(x, y)
    }
  }
}